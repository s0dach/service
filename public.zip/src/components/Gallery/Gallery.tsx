import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import './Gallery.css';

interface GalleryImage {
  id: number;
  title: string;
  category: string;
  placeholder: string;
}

const galleryImages: GalleryImage[] = [
  { id: 1, title: 'Диагностическое оборудование', category: 'equipment', placeholder: 'Современное диагностическое оборудование' },
  { id: 2, title: 'Рабочее место мастера', category: 'workspace', placeholder: 'Оборудованное рабочее место' },
  { id: 3, title: 'Ремонт двигателя', category: 'repair', placeholder: 'Процесс ремонта двигателя' },
  { id: 4, title: 'Покрасочная камера', category: 'equipment', placeholder: 'Профессиональная покрасочная камера' },
  { id: 5, title: 'Готовый автомобиль', category: 'result', placeholder: 'Автомобиль после ремонта' },
  { id: 6, title: 'Команда мастеров', category: 'team', placeholder: 'Наша профессиональная команда' },
  { id: 7, title: 'Подъемник', category: 'equipment', placeholder: 'Гидравлический подъемник' },
  { id: 8, title: 'Кузовной ремонт', category: 'repair', placeholder: 'Восстановление кузова' },
  { id: 9, title: 'Клиентская зона', category: 'workspace', placeholder: 'Комфортная зона ожидания' }
];

const categories = [
  { id: 'all', name: 'Все фото' },
  { id: 'equipment', name: 'Оборудование' },
  { id: 'workspace', name: 'Рабочие места' },
  { id: 'repair', name: 'Ремонт' },
  { id: 'result', name: 'Результаты' },
  { id: 'team', name: 'Команда' }
];

const Gallery: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState('all');
  const [selectedImage, setSelectedImage] = useState<GalleryImage | null>(null);

  const filteredImages = activeCategory === 'all' 
    ? galleryImages 
    : galleryImages.filter(img => img.category === activeCategory);

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, scale: 0.8 },
    visible: {
      opacity: 1,
      scale: 1,
      transition: {
        duration: 0.5
      }
    }
  };

  return (
    <section id="gallery" className="gallery section-padding">
      <div className="container">
        <motion.div 
          className="gallery__header text-center"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <h2 className="heading-lg">Наша галерея</h2>
          <p className="text-lg gallery__subtitle">
            Посмотрите на наше оборудование, рабочие места и результаты работы
          </p>
        </motion.div>

        <motion.div 
          className="gallery__filters"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          viewport={{ once: true }}
        >
          {categories.map((category) => (
            <button
              key={category.id}
              className={`gallery__filter ${activeCategory === category.id ? 'gallery__filter--active' : ''}`}
              onClick={() => setActiveCategory(category.id)}
            >
              {category.name}
            </button>
          ))}
        </motion.div>

        <motion.div 
          className="gallery__grid"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          key={activeCategory}
        >
          <AnimatePresence mode="wait">
            {filteredImages.map((image) => (
              <motion.div
                key={image.id}
                className="gallery__item"
                variants={itemVariants}
                whileHover={{ y: -8 }}
                onClick={() => setSelectedImage(image)}
                layout
              >
                <div className="gallery__image-placeholder">
                  <div className="gallery__image-content">
                    <div className="gallery__image-icon">📸</div>
                    <div className="gallery__image-text">{image.placeholder}</div>
                  </div>
                  <div className="gallery__image-overlay">
                    <div className="gallery__image-title">{image.title}</div>
                    <div className="gallery__image-zoom">🔍</div>
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>

        {/* Модальное окно */}
        <AnimatePresence>
          {selectedImage && (
            <motion.div
              className="gallery__modal"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedImage(null)}
            >
              <motion.div
                className="gallery__modal-content"
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.8, opacity: 0 }}
                onClick={(e) => e.stopPropagation()}
              >
                <button
                  className="gallery__modal-close"
                  onClick={() => setSelectedImage(null)}
                >
                  ✕
                </button>
                <div className="gallery__modal-image">
                  <div className="gallery__modal-placeholder">
                    <div className="gallery__modal-icon">📸</div>
                    <div className="gallery__modal-text">{selectedImage.placeholder}</div>
                  </div>
                </div>
                <div className="gallery__modal-info">
                  <h3>{selectedImage.title}</h3>
                  <p>Здесь будет ваша фотография: {selectedImage.placeholder}</p>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </section>
  );
};

export default Gallery;

